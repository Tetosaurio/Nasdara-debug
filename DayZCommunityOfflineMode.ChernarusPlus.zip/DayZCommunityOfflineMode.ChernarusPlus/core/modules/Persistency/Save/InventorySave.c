class InventorySave : ItemSave
{
}